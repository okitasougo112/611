class DirectDownloadLinkException(Exception):
    pass
